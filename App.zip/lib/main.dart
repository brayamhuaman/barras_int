import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:ml_linalg/linalg.dart';

class IAHelper {
  final String serverIp;
  final Function(String)? onPredictionReceived;
  final Function(int)? oncontador;

  IAHelper(this.serverIp, {this.onPredictionReceived, this.oncontador});

  final int bufferSize = 10; // Reducido a 10
  final int predictionWindow = 10; // Mantiene el buffer de predicción en 10
  List<int> dataBuffer = List.filled(10, 0, growable: false);
  List<bool> predictionBuffer = List.filled(10, false, growable: false);
  List<double> realTimeInput = List.filled(10, 0.0, growable: false);

  int prevPrediction = 0;
  int contador = 0;
  bool isSending = false;

  void addData(int newValue) {
    newValue = newValue.clamp(0, 100);
    dataBuffer = [...dataBuffer.sublist(1), newValue];

    // Optimizar media móvil con ml_linalg
    final vector =
        Vector.fromList(dataBuffer.map((e) => e.toDouble()).toList());
    double movingAverage = vector.mean();
    realTimeInput = [...realTimeInput.sublist(1), movingAverage];

    if (!isSending && realTimeInput.length == bufferSize) {
      sendToServer();
    }
  }

  Future<void> sendToServer() async {
    if (realTimeInput.length < 10) return;
    isSending = true;

    final List<double> last10Data =
        realTimeInput.sublist(realTimeInput.length - 10);
    final url = Uri.parse("http://$serverIp/predict");

    final vector = Vector.fromList(last10Data);
    double promedio = vector.mean(); // Cálculo optimizado con ml_linalg

    if (promedio >= 80) {
      // Si el promedio es 80 o más, no consulta
      print("🚫 Evitando consulta: el promedio es $promedio (≥ 80)");
      isSending = false;
      return;
    }

    try {
      final response = await http.post(
        url,
        headers: {"Content-Type": "application/json"},
        body: jsonEncode({"inputs": last10Data}),
      );

      if (response.statusCode == 200) {
        final Map<String, dynamic> jsonResponse = jsonDecode(response.body);
        dynamic predictionData = jsonResponse["prediction"];
        bool prediction = (predictionData is List && predictionData.isNotEmpty)
            ? (predictionData.first as int) < 200
            : (predictionData as int) < 200;

        // Reducir buffer de predicción a 10
        predictionBuffer = [...predictionBuffer.sublist(1), prediction];

        // Media de predicciones optimizada con ml_linalg
        final predictionVector = Vector.fromList(
            predictionBuffer.map((p) => p ? 1.0 : 0.0).toList());
        bool currentPrediction = predictionVector.mean() > 0.45;

        // Detectar transición 1 → 0
        if (prevPrediction == 1 && !currentPrediction) {
          contador++;
          print("🔄 Transición detectada (1 → 0), nuevo contador: $contador");
          oncontador?.call(contador);
        }

        prevPrediction = currentPrediction ? 1 : 0;
        print("✅ Predicción recibida: $currentPrediction");

        onPredictionReceived?.call(currentPrediction.toString());
      } else {
        print("❌ Error en la respuesta: ${response.statusCode}");
      }
    } catch (e) {
      print("❌ Error enviando datos: $e");
    } finally {
      isSending = false;
    }
  }
}

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Smart Pull-Up Bar',
      theme: ThemeData(
        primarySwatch: Colors.blue,
        scaffoldBackgroundColor: Colors.grey[100],
        appBarTheme: AppBarTheme(
          backgroundColor: Colors.white,
          foregroundColor: Colors.blue,
          elevation: 0,
        ),
      ),
      home: BleScreen(),
    );
  }
}

class BleScreen extends StatefulWidget {
  @override
  _BleScreenState createState() => _BleScreenState();
}

class _BleScreenState extends State<BleScreen> {
  String serverResponse = "Sin predicción";
  int barras = 0;
  BluetoothDevice? device;
  String batteryLevel = "N/A";
  List<BluetoothService>? services;
  List<BluetoothDevice> devicesList = [];
  bool scanning = false;
  BluetoothCharacteristic? targetCharacteristic;
  BluetoothCharacteristic? batteryCharacteristic;
  int pullUpCount = 0;
  String connectionStatus = 'Desconectado';
  int previousValue = 0;
  String serverIp = "";
  IAHelper? _iaHelper;

  Future<bool> _connectToDevice(int index) async {
    try {
      setState(() => connectionStatus = 'Conectando...');
      device = devicesList[index];
      await device?.connect();
      setState(() => connectionStatus = 'Buscando servicios...');
      await _discoverServices();
      setState(() => connectionStatus = 'Suscribiendo...');
      bool subscribed = await _subscribeToCharacteristic();
      setState(() => connectionStatus = subscribed
          ? 'Conectado y suscrito'
          : 'Conectado pero sin suscripción');
      return true;
    } catch (e) {
      setState(() => connectionStatus = 'Error: $e');
      print('Error connecting: $e');
      return false;
    }
  }

  Future<void> _discoverServices() async {
    if (device == null) return;

    try {
      services = await device!.discoverServices();
      for (var service in services!) {
        print('🔹 Servicio: ${service.uuid}');
        for (var characteristic in service.characteristics) {
          print('  ➡ Característica: ${characteristic.uuid}');
        }
      }
    } catch (e) {
      print('❌ Error descubriendo servicios: $e');
    }
  }

  Future<bool> _subscribeToCharacteristic() async {
    try {
      if (services == null) return false;
      final targetUuid = Guid('beb5483e-36e1-4688-b7f5-ea07361b26a8');
      final batteryUuid = Guid('d9d9fbb3-03a5-4bda-9e44-916ffb9470b1');
      for (var service in services!) {
        for (var characteristic in service.characteristics) {
          if (characteristic.uuid == targetUuid) {
            targetCharacteristic = characteristic;
            if (characteristic.properties.notify) {
              await characteristic.setNotifyValue(true);
              characteristic.onValueReceived.listen((value) {
                print('Received value: $value');
                if (value.isNotEmpty) {
                  int newValue = value[0];
                  setState(() => pullUpCount = newValue);
                  _iaHelper?.addData(newValue);
                }
              });
            }
          }

          if (characteristic.uuid == batteryUuid) {
            batteryCharacteristic = characteristic;
            if (characteristic.properties.notify) {
              await characteristic.setNotifyValue(true);
              characteristic.onValueReceived.listen((value) {
                if (value.isNotEmpty) {
                  setState(() {
                    batteryLevel = "${value[0]}%";
                  });
                }
              });
            }
          }
        }
      }
      return false;
    } catch (e) {
      print('Error subscribing: $e');
      return false;
    }
  }

  void _startScan() async {
    if (scanning) {
      await FlutterBluePlus.stopScan();
      setState(() => scanning = false);
    } else {
      setState(() {
        devicesList.clear();
        scanning = true;
      });
      await FlutterBluePlus.startScan(timeout: Duration(seconds: 5));
      FlutterBluePlus.scanResults.listen((results) {
        setState(() {
          devicesList = results
              .map((r) => r.device)
              .where((d) => d.name.isNotEmpty)
              .toList();
        });
      }).onDone(() => setState(() => scanning = false));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Smart Pull-Up Bar'), centerTitle: true),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Text('Estado de batería: $batteryLevel',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
            TextField(
              decoration: InputDecoration(
                labelText: 'IP del Servidor',
                border: OutlineInputBorder(),
              ),
              onChanged: (value) {
                setState(() {
                  serverIp = value;
                  _iaHelper =
                      IAHelper(serverIp, onPredictionReceived: (prediction) {
                    // prediction es el parámetro String
                    setState(() {
                      serverResponse = prediction;
                    });
                  }, oncontador: (value) {
                    setState(() {
                      barras = value;
                    });
                  });
                });
              },
            ),
            SizedBox(height: 20),
            Text('Predicción del Modelo: $serverResponse',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500)),
            Text('Media Sensor: $pullUpCount',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            Text('Contador: $barras',
                style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
            ElevatedButton.icon(
              onPressed: () {
                setState(() {
                  barras = 0;
                  _iaHelper?.contador =
                      0; // Reiniciar el contador dentro de IAHelper
                });
              },
              icon: Icon(Icons.refresh),
              label: Text('Reiniciar'),
            ),
            ElevatedButton.icon(
              onPressed: _startScan,
              icon: Icon(scanning ? Icons.stop : Icons.bluetooth_searching),
              label:
                  Text(scanning ? 'Detener Búsqueda' : 'Buscar Dispositivos'),
            ),
            Expanded(
              child: ListView.builder(
                itemCount: devicesList.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(devicesList[index].name),
                    subtitle: Text(devicesList[index].id.toString()),
                    trailing: Icon(Icons.bluetooth),
                    onTap: () => _connectToDevice(index),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
